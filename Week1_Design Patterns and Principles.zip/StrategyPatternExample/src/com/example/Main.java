package com.example;

import com.example.gui.PaymentSystemGUI;

public class Main {
    public static void main(String[] args) {
        PaymentSystemGUI paymentSystemGUI = new PaymentSystemGUI();
        paymentSystemGUI.setVisible(true);
    }
}
