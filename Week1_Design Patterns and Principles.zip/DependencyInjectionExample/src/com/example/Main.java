// src/com/example/Main.java
package com.example;

import com.example.repository.CustomerRepository;
import com.example.repository.CustomerRepositoryImpl;
import com.example.service.CustomerService;
import com.example.gui.CustomerManagementGUI;

public class Main {
    public static void main(String[] args) {
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);
        CustomerManagementGUI gui = new CustomerManagementGUI(service);
        gui.setVisible(true);
    }
}
