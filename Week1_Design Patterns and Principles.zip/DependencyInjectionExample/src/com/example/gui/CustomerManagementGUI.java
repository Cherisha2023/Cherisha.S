// src/com/example/gui/CustomerManagementGUI.java
package com.example.gui;

import com.example.service.CustomerService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CustomerManagementGUI extends JFrame {
    private CustomerService customerService;
    private JTextField customerIdField;
    private JTextArea resultArea;

    public CustomerManagementGUI(CustomerService customerService) {
        this.customerService = customerService;
        setTitle("Customer Management");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        panel.add(customerIdField);

        JButton findButton = new JButton("Find Customer");
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findCustomer();
            }
        });
        panel.add(findButton);

        add(panel, BorderLayout.NORTH);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    private void findCustomer() {
        try {
            int id = Integer.parseInt(customerIdField.getText());
            String customer = customerService.getCustomerById(id);
            resultArea.setText(customer);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

