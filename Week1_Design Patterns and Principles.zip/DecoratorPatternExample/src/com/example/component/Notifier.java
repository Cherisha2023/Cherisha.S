package com.example.component;

public interface Notifier {
    void send(String message);
}

