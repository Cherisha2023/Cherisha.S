package documents;
public abstract class Document {
    public abstract void open();
    public abstract void close();
    public abstract void save();
}

