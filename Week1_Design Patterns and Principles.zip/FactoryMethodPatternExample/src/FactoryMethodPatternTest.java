//A Java program to test the Factory Method Pattern
import documents.Document;
import factories.DocumentFactory;
import factories.PdfDocumentFactory;
import factories.WordDocumentFactory;
import factories.ExcelDocumentFactory;
//Implementing the Factory Method Pattern Technique to handle different types of documents
public class FactoryMethodPatternTest {
    public static void main(String[] args) {
        //Creating an object of the Document Factory class
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDoc = wordFactory.createDocument();
        wordDoc.open();
        wordDoc.save();
        wordDoc.close();
        //Creating an object of the Pdf Document Factory class
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document pdfDoc = pdfFactory.createDocument();
        pdfDoc.open();
        pdfDoc.save();
        pdfDoc.close();
        //Creating an object of the Excel Document Factory class
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document excelDoc = excelFactory.createDocument();
        excelDoc.open();
        excelDoc.save();
        excelDoc.close();
    }
}
