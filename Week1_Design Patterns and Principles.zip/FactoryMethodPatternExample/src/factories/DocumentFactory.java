package factories;

import documents.Document;
//Declaration of Abstract class
public abstract class DocumentFactory {
    public abstract Document createDocument();
}

