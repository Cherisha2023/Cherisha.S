package com.example;

import com.example.gui.HomeAutomationGUI;

public class Main {
    public static void main(String[] args) {
        HomeAutomationGUI homeAutomationGUI = new HomeAutomationGUI();
        homeAutomationGUI.setVisible(true);
    }
}
