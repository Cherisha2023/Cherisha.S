package com.example.adaptee;

public class PayPal {
    public void makePayment(String amount) {
        System.out.println("Processing payment of " + amount + " through PayPal.");
    }
}

